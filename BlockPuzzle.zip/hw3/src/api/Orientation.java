package api;

/**
 * Enum representing the orientation of a boulder.
 * 
 * @author tancreti
 */
public enum Orientation {
	VERTICAL, HORIZONTAL;
}